d3 = {version: "2.10.0"}; // semver
